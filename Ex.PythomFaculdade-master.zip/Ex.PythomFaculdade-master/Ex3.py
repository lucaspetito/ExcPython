num1 = int(input("Digite o primeiro número :"))
num2 = int(input("Digite o segundo número :"))
R = num1 + num2
print("A Soma dos dois números digitados é :",R)


