num1 = float(input("Digite o tamanho do lado do quadrado :"))
R = num1*num1*2
print("O valor do dobro da área do quadrado de lado ",num1,", é igual a ",R)