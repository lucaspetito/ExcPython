
print("Hello, World!")
print("Alo, Mundo!")