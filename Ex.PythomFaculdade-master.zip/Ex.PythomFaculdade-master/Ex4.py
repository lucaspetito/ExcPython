num1 = int(input("Digite sua primeira nota Bimestral:"))
num2 = int(input("Digite sua segunda nota Bimestral:"))
num3 = int(input("Digite sua terceira nota Bimestral:"))
num4 = int(input("Digite sua quarta nota Bimestral:"))
R = (num1+num2+num3+num4)/4

print("Sua média Bimestral é igual a : ", R)
