num1 = float(input("Digite a temperatura em graus Celsius :"))
R = ((num1/5)*9)+32
print(num1," Celsius equivalem a",R,"graus Fahrenheit")

