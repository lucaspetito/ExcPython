num1 = float(input("Digite a temperatura em graus Fahrenheit :"))
R = 5*((num1-32)/9)
print(num1," Fahrenheit equivalem a",R,"graus celsius")