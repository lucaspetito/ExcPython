H = float(input("Digite sua altura em metros :"))
Sexo = input("Digite qual seu sexo, Masculino(M) ou Feminino(F) : \n")

if (Sexo == "M"):
        Peso =(72.7*H)-58
        print("Seu peso ideal é igual a : ",Peso)
else:
        Peso =(62.1*H)-44.7
        print("Seu peso ideal é igual a : ",Peso)




