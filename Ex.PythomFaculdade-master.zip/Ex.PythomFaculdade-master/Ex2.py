from unicodedata import numeric


num = input("Digite um número: ")
print("Você digitou o número:",num)