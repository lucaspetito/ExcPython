from cmath import pi
from numbers import Real


num1 = float(input("Digite o tamanho do raio do círculo :"))
R = pi*num1*num1
print("O valor da área do circulo de raio ",num1,", é igual a ",R)