num1 = float(input("Qual a quantidade em metros a ser pintada ? "))

Quantidade = num1/3
Preco = Quantidade*(80/18)
Latas = num1/54
print("A Quantidade de latas q serem usadas é igual a : ",Latas)
print ("O Preço a ser pago é igual a : ",Preco, " Reais")