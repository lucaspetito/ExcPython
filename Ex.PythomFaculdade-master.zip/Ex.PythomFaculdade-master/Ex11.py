from numbers import Real


num1 = int(input("Digite o primerio numero inteiro :"))
num2 = int(input("Digite o segundo numero inteiro :"))
num3 = float(input("Digite um numero real :"))

print("o produto do dobro do primeiro com metade do segundo : \n",(2*num1)*(num2/2))
print("a soma do triplo do primeiro com o terceiro : \n", (3*num1)+ num3)
print("o terceiro elevado ao cubo : \n", num3*num3*num3)