num1 = int(input("Digite uma metragem em metros :"))
R = num1*100
print(num1,"metros é igual a ",R,"Centímetros")