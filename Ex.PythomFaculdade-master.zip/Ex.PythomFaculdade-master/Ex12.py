H = float(input("Digite sua altura em metros"))
Peso =(72.7*H)-58
print("Seu peso ideal é igual a : ",Peso)